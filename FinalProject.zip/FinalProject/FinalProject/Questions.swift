//
//  Questions.swift
//  FinalProject
//
//  Created by Kranthi Chinnakotla on 11/2/16.
//  Copyright © 2016 edu.uncc.cs6010. All rights reserved.
//

import Foundation
public class Questions{
    var step = Int()
    var question = String()
    var answer = String()
    var imageUrl: NSURL?
    
    
}
