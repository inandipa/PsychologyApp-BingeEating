//
//  AppointmentsClass.swift
//  FinalProject
//
//  Created by Kranthi Chinnakotla on 11/26/16.
//  Copyright © 2016 edu.uncc.cs6010. All rights reserved.
//

import Foundation

public class AppointmentsClass{
    var userName = String()
    var timeOfAppointment = String()
    var supporter = String()
    }
