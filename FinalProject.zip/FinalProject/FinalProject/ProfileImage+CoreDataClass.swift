//
//  ProfileImage+CoreDataClass.swift
//  FinalProject
//
//  Created by Kranthi Chinnakotla on 11/19/16.
//  Copyright © 2016 edu.uncc.cs6010. All rights reserved.
//

import Foundation
import CoreData


public class ProfileImage: NSManagedObject {

}
