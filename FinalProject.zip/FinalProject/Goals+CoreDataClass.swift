//
//  Goals+CoreDataClass.swift
//  FinalProject
//
//  Created by Kranthi Chinnakotla on 11/27/16.
//  Copyright © 2016 edu.uncc.cs6010. All rights reserved.
//

import Foundation
import CoreData


public class Goals: NSManagedObject {

  
}
